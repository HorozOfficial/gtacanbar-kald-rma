# b2k-minimap
Removes HP/ARMOUR on Minimap + Removes Red Reticle